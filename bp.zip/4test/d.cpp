#include <bits/stdc++.h>
using namespace std;
int main()
{
    int n;
    cin>>n;
    int arr[n][2];
    int tmp;
    for (int i=0;i<n;i++)
        {for (int j=0;j<2;j++)
            {cin>>arr[i][j];}
        }
    for (int i=0;i<n;i++)
        {for (int j=0;j<2;j++)
            {if (arr[i][j]>arr[i][j+1])
            {swap(arr[i][j],arr[i][j+1]);
            }
            }
        }
    for (int i=0;i<n;i++)
        {for (int j=0;j<2;j++)
            {cout<<arr[i][j]<<" ";}
            cout<<endl;
        }
    
