#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

int main() {
    int n;
    cin >> n;

    double sum_ma = 0.0, sum_p= 0.0, sum_i = 0.0;

    for (int i = 0; i < n; ++i) {
        string s, n;
        int m, p, i;
        cin >> s >> n >> m>> p> i;
        sum_m += m;
        sum_p+= p;
        sum_i += i;
    }

    double avg_m= sum_m/ n;
    double avg_p= sum_p / n;
    double avg_i= sum_i/ n;

    cout << fixed << setprecision(6)
         << avg_m<< " " << avg_p<< " " << avg_i << endl;

    return 0;
}