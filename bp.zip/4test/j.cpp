#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

struct Student {
    string surname;
    string name;
    double average;
};

int main() {
    int n;
    cin >> n;

    vector<Student> students;

    for (int i = 0; i < n; ++i) {
        string surname, name;
        int math_score, physics_score, info_score;

        cin >> surname >> name >> math_score >> physics_score >> info_score;

        double average = (math_score + physics_score + info_score) / 3.0;
        students.push_back({surname, name, average});
    }

    sort(students.begin(), students.end(), [](const Student& a, const Student& b) {
        return a.average > b.average;
    });

    double third_place_average = students.size() > 2 ? students[2].average : -1.0;
    vector<Student> best_students;

    for (const auto& student : students) {
        if (best_students.size() < 3 || student.average == third_place_average) {
            best_students.push_back(student);
        }
    }

    for (const auto& student : best_students) {
        cout << student.surname << " " << student.name << endl;
    }

    return 0;
}
