#include <iostream>
using namespace std;
int main()
{
int x0, x1, y0, y1;
cin >> x0 >> y0 >> x1 >> y1; 
if(abs(x1 - x0) == abs(y1 - y0))
cout << "yes";
else cout << "no";
return 0;
}